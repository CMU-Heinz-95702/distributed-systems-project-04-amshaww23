package com.example.spotifysearchapp;

// Import statements
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.snackbar.Snackbar;
import com.example.spotifysearchapp.databinding.ActivityMainBinding;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;

/**
 * Author: DingHua Xiao
 * AndrewID: dinghuax
 *
 * MainActivity is the main entry point of the Spotify Search Android application.
 * It handles user interactions for searching artists and displays the results retrieved from the server.
 */
public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Server URL for the backend SpotifySearchServlet
    private static final String SERVER_URL = "https://your-server-url/SpotifySearchServlet";

    // OkHttpClient instance with custom SSL settings
    private final OkHttpClient client = getUnsafeOkHttpClient();

    /**
     * Creates an OkHttpClient instance that trusts all SSL certificates.
     * Note: This is not recommended for production apps due to security risks.
     *
     * @return OkHttpClient that trusts all SSL certificates
     */
    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] chain, String authType) { }

                        @Override
                        public void checkServerTrusted(X509Certificate[] chain, String authType) { }

                        @Override
                        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[]{}; }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

            // Build the OkHttpClient with the custom SSL settings
            return new OkHttpClient.Builder()
                    .sslSocketFactory(sslContext.getSocketFactory(), (X509TrustManager) trustAllCerts[0])
                    .hostnameVerifier((hostname, session) -> true)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Initiates a search request to the server using the provided search term.
     *
     * @param searchTerm the artist name to search for
     */
    private void performSearch(String searchTerm) {
        try {
            // Encode the search term for inclusion in the URL
            String encodedTerm = Uri.encode(searchTerm);
            String url = SERVER_URL + "?term=" + encodedTerm;
            Log.d("SpotifyApp", "Request URL: " + url);

            // Build the HTTP request
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("Accept", "application/json")
                    .build();

            // Execute the request asynchronously
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    // Handle network errors
                    Log.e("SpotifyApp", "Network error: " + e.getMessage(), e);
                    mainHandler.post(() -> {
                        binding.resultsText.setText("Error: " + e.getMessage() + "\nURL: " + url);
                    });
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    // Handle successful response
                    final String responseData = response.body().string();
                    Log.d("SpotifyApp", "Response code: " + response.code());
                    Log.d("SpotifyApp", "Response: " + responseData);

                    if (!response.isSuccessful()) {
                        // Handle server-side errors
                        mainHandler.post(() -> {
                            binding.resultsText.setText("Server error: " + response.code() + "\n" + responseData);
                        });
                        return;
                    }

                    mainHandler.post(() -> {
                        try {
                            // Parse the JSON response
                            JSONObject json = new JSONObject(responseData);
                            JSONObject artists = json.getJSONObject("artists");
                            JSONArray items = artists.getJSONArray("items");

                            StringBuilder displayText = new StringBuilder();
                            // Iterate over the artist items and build the display text
                            for (int i = 0; i < items.length(); i++) {
                                JSONObject artist = items.getJSONObject(i);
                                String name = artist.getString("name");
                                int popularity = artist.getInt("popularity");
                                JSONObject followers = artist.getJSONObject("followers");
                                int followerCount = followers.getInt("total");

                                displayText.append(name)
                                        .append("\nPopularity: ").append(popularity)
                                        .append("\nFollowers: ").append(String.format("%,d", followerCount))
                                        .append("\n\n");
                            }

                            // Display the results in the TextView
                            binding.resultsText.setText(displayText.toString());
                        } catch (JSONException e) {
                            // Handle JSON parsing errors
                            Log.e("SpotifyApp", "JSON parsing error", e);
                            binding.resultsText.setText("Error parsing response: " + responseData);
                        }
                    });
                }
            });
        } catch (Exception e) {
            // Handle other exceptions
            Log.e("SpotifyApp", "Error in performSearch", e);
            binding.resultsText.setText("Error: " + e.getMessage());
        }
    }

    /**
     * Inflates the options menu.
     *
     * @param menu the menu object to inflate
     * @return true if the menu was successfully inflated
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    /**
     * Handles action bar item clicks.
     *
     * @param item the menu item that was selected
     * @return true if the action was handled
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        // Handle action bar item clicks here
        if (id == R.id.action_settings) {
            // Open settings activity or perform related action
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Called when the activity is starting.
     *
     * @param savedInstanceState if the activity is being re-initialized after previously being shut down
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflate the layout using View Binding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Set up the toolbar
        setSupportActionBar(binding.toolbar);

        // Set up click listener for the search button
        binding.searchButton.setOnClickListener(view -> {
            performSearchFromInput();
        });

        // Set up listener for the keyboard search action
        binding.searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                performSearchFromInput();
                return true;
            }
            return false;
        });
    }

    /**
     * Retrieves the search term from the input field and initiates the search.
     */
    private void performSearchFromInput() {
        String searchTerm = binding.searchInput.getText().toString().trim();
        if (!searchTerm.isEmpty()) {
            binding.resultsText.setText("Searching...");
            performSearch(searchTerm);
        } else {
            // Show a message if the search term is empty
            Snackbar.make(binding.getRoot(), "Please enter a search term", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
        }
    }
}
